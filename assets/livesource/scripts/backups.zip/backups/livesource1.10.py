import urllib.request
from urllib.parse import urlparse
import re #正则
import os
from datetime import datetime, timedelta, timezone
import random
import opencc #简繁转换

import socket
import time

#简繁转换
def traditional_to_simplified(text: str) -> str:
    # 初始化转换器，"t2s" 表示从繁体转为简体
    converter = opencc.OpenCC('t2s')
    simplified_text = converter.convert(text)
    return simplified_text

# 执行开始时间
timestart = datetime.now()
# 报时  '',
#print(f"time: {datetime.now().strftime("%Y%m%d_%H_%M_%S")}")

#读取文本方法
def read_txt_to_array(file_name):
    try:
        with open(file_name, 'r', encoding='utf-8') as file:
            lines = file.readlines()
            lines = [line.strip() for line in lines if line.strip()]  # 跳过空行
            return lines
    except FileNotFoundError:
        print(f"File '{file_name}' not found.")
        return []
    except Exception as e:
        print(f"An error occurred: {e}")
        return []

#read BlackList 2024-06-17 15:02
def read_blacklist_from_txt(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    BlackList = [line.split(',')[1].strip() for line in lines if ',' in line]
    return BlackList

blacklist_auto=read_blacklist_from_txt('assets/livesource/blacklist/blacklist_auto.txt') 
blacklist_manual=read_blacklist_from_txt('assets/livesource/blacklist/blacklist_manual.txt') 
# combined_blacklist = list(set(blacklist_auto + blacklist_manual))
combined_blacklist = set(blacklist_auto + blacklist_manual)  #list是个列表，set是个集合，据说检索速度集合要快很多。2024-08-08

# ========= 初始化输出目录 =========
os.makedirs('output', exist_ok=True)
print("创建输出目录: output")

# ========= 频道分类存储变量定义 =========

# 核心频道（优先级最高）
yangshi_lines = []
weishi_lines = []

# 省级地方台频道
beijing_lines = []
shanghai_lines = []
guangdong_lines = []
jiangsu_lines = []
zhejiang_lines = []
shandong_lines = []
sichuan_lines = []
henan_lines = []
hunan_lines = []
chongqing_lines = []
tianjin_lines = []
hubei_lines = []
anhui_lines = []
fujian_lines = []
liaoning_lines = []
shaanxi_lines = []
hebei_lines = []
jiangxi_lines = []
guangxi_lines = []
yunnan_lines = []
shanxi_lines = []
heilongjiang_lines = []
jilin_lines = []
guizhou_lines = []
gansu_lines = []
neimenggu_lines = []
xinjiang_lines = []
hainan_lines = []
ningxia_lines = []
qinghai_lines = []
xizang_lines = []

# 港澳台频道
hongkong_lines = []
macau_lines = []
minnan_lines = []

# 其他分类频道
digital_lines = []
movie_lines = []
tv_drama_lines = []
documentary_lines = []
cartoon_lines = []
radio_lines = []
variety_lines = []
huya_lines = []
douyu_lines = []
commentary_lines = []
music_lines = []
food_lines = []
travel_lines = []
health_lines = []
finance_lines = []
shopping_lines = []
game_lines = []
news_lines = []
china_lines = []
international_lines = []
sports_lines = []
tyss_lines = []
mgss_lines = []
traditional_opera_lines = []
spring_festival_gala_lines = []
camera_lines = []
favorite_lines = []

# 未分类频道（兜底处理）
other_lines = []
other_lines_url = []

def process_name_string(input_str):
    parts = input_str.split(',')
    processed_parts = []
    for part in parts:
        processed_part = process_part(part)
        processed_parts.append(processed_part)
    result_str = ','.join(processed_parts)
    return result_str

def process_part(part_str):
    # 处理逻辑
    if "CCTV" in part_str  and "://" not in part_str:
        part_str=part_str.replace("IPV6", "")  #先剔除IPV6字样
        part_str=part_str.replace("PLUS", "+")  #替换PLUS
        part_str=part_str.replace("1080", "")  #替换1080
        filtered_str = ''.join(char for char in part_str if char.isdigit() or char == 'K' or char == '+')
        if not filtered_str.strip(): #处理特殊情况，如果发现没有找到频道数字返回原名称
            filtered_str=part_str.replace("CCTV", "")

        if len(filtered_str) > 2 and re.search(r'4K|8K', filtered_str):   # 特殊处理CCTV中部分4K和8K名称
            # 使用正则表达式替换，删除4K或8K后面的字符，并且保留4K或8K
            filtered_str = re.sub(r'(4K|8K).*', r'\1', filtered_str)
            if len(filtered_str) > 2: 
                # 给4K或8K添加括号
                filtered_str = re.sub(r'(4K|8K)', r'(\1)', filtered_str)

        return "CCTV"+filtered_str 
        
    elif "卫视" in part_str:
        # 定义正则表达式模式，匹配“卫视”后面的内容
        pattern = r'卫视「.*」'
        # 使用sub函数替换匹配的内容为空字符串
        result_str = re.sub(pattern, '卫视', part_str)
        return result_str
    
    return part_str

# 准备支持m3u格式
def get_url_file_extension(url):
    # 解析URL
    parsed_url = urlparse(url)
    # 获取路径部分
    path = parsed_url.path
    # 提取文件扩展名
    extension = os.path.splitext(path)[1]
    return extension

def convert_m3u_to_txt(m3u_content):
    # 分行处理
    lines = m3u_content.split('\n')
    
    # 用于存储结果的列表
    txt_lines = []
    
    # 临时变量用于存储频道名称
    channel_name = ""
    
    for line in lines:
        # 过滤掉 #EXTM3U 开头的行
        if line.startswith("#EXTM3U"):
            continue
        # 处理 #EXTINF 开头的行
        if line.startswith("#EXTINF"):
            # 获取频道名称（假设频道名称在引号后）
            channel_name = line.split(',')[-1].strip()
        # 处理 URL 行
        elif line.startswith("http") or line.startswith("rtmp") or line.startswith("p3p") :
            txt_lines.append(f"{channel_name},{line.strip()}")
        
        # 处理后缀名为m3u，但是内容为txt的文件
        if "#genre#" not in line and "," in line and "://" in line:
            # 定义正则表达式，匹配频道名称,URL 的格式，并确保 URL 包含 "://"
            # xxxx,http://xxxxx.xx.xx
            pattern = r'^[^,]+,[^\s]+://[^\s]+$'
            if bool(re.match(pattern, line)):
                txt_lines.append(line)
    
    # 将结果合并成一个字符串，以换行符分隔
    return '\n'.join(txt_lines)

# 在list是否已经存在url 2024-07-22 11:18
def check_url_existence(data_list, url):
    """
    Check if a given URL exists in a list of data.

    :param data_list: List of strings containing the data
    :param url: The URL to check for existence
    :return: True if the URL exists in the list, otherwise False
    """
    # Extract URLs from the data list
    urls = [item.split(',')[1] for item in data_list]
    return url not in urls #如果不存在则返回true，需要

# 处理带$的URL，把$之后的内容都去掉（包括$也去掉） 【2024-08-08 22:29:11】
def clean_url(url):
    last_dollar_index = url.rfind('$')  # 安全起见找最后一个$处理
    if last_dollar_index != -1:
        return url[:last_dollar_index]
    return url

# 添加channel_name前剔除部分特定字符
removal_list = ["_电信", "电信", "高清", "频道", "（HD）", "-HD","英陆","_ITV","(北美)","(HK)","AKtv","「IPV4」","「IPV6」",
                "频陆","备陆","壹陆","贰陆","叁陆","肆陆","伍陆","陆陆","柒陆", "频晴","频粤","[超清]","高清","超清","标清","斯特",
                "粤陆", "国陆","肆柒","频英","频特","频国","频壹","频贰","肆贰","频测","咪咕","闽特","高特","频高","频标","汝阳",
                "4Gtv","频效","国标","粤标","频推","频流","粤高","频限","实时","美推","频美"]
def clean_channel_name(channel_name, removal_list):
    for item in removal_list:
        channel_name = channel_name.replace(item, "")

    # 检查并移除末尾的 'HD'
    if channel_name.endswith("HD"):
        channel_name = channel_name[:-2]  # 去掉最后两个字符 "HD"
    
    if channel_name.endswith("台") and len(channel_name) > 3:
        channel_name = channel_name[:-1]  # 去掉最后两个字符 "台"

    return channel_name

# 分发直播源，归类，把这部分从process_url剥离出来，为以后加入whitelist源清单做准备。
def process_channel_line(line):
    if  "#genre#" not in line and "#EXTINF:" not in line and "," in line and "://" in line:
        channel_name=line.split(',')[0].strip()
        channel_name= clean_channel_name(channel_name, removal_list)  #分发前清理channel_name中特定字符
        channel_name = traditional_to_simplified(channel_name)  #繁转简

        channel_address=clean_url(line.split(',')[1].strip())  #把URL中$之后的内容都去掉
        line=channel_name+","+channel_address #重新组织line

        if channel_address not in combined_blacklist: # 判断当前源是否在blacklist中
            # 根据行内容判断存入哪个对象，开始分发
            if "CCTV" in channel_name and check_url_existence(yangshi_lines, channel_address):
                yangshi_lines.append(process_name_string(line.strip()))
            elif channel_name in weishi_dictionary and check_url_existence(weishi_lines, channel_address):
                weishi_lines.append(process_name_string(line.strip()))
            elif channel_name in sports_dictionary and check_url_existence(sports_lines, channel_address):
                sports_lines.append(process_name_string(line.strip()))
            elif any(tyss_keyword in channel_name for tyss_keyword in tyss_dictionary) and check_url_existence(tyss_lines, channel_address):
                tyss_lines.append(process_name_string(line.strip()))
            elif any(mgss_keyword in channel_name for mgss_keyword in mgss_dictionary) and check_url_existence(mgss_lines, channel_address):
                mgss_lines.append(process_name_string(line.strip()))
            elif channel_name in movie_dictionary and check_url_existence(movie_lines, channel_address):
                movie_lines.append(process_name_string(line.strip()))
            elif channel_name in tv_drama_dictionary and check_url_existence(tv_drama_lines, channel_address):
                tv_drama_lines.append(process_name_string(line.strip()))
            elif channel_name in shanghai_dictionary and check_url_existence(shanghai_lines, channel_address):
                shanghai_lines.append(process_name_string(line.strip()))
            elif channel_name in hongkong_dictionary and check_url_existence(hongkong_lines, channel_address):
                hongkong_lines.append(process_name_string(line.strip()))
            elif channel_name in macau_dictionary and check_url_existence(macau_lines, channel_address):
                macau_lines.append(process_name_string(line.strip()))
            elif channel_name in minnan_dictionary and check_url_existence(minnan_lines, channel_address):
                minnan_lines.append(process_name_string(line.strip()))
            elif channel_name in international_dictionary and check_url_existence(international_lines, channel_address):
                international_lines.append(process_name_string(line.strip()))
            elif channel_name in documentary_dictionary and check_url_existence(documentary_lines, channel_address):
                documentary_lines.append(process_name_string(line.strip()))
            elif channel_name in cartoon_dictionary and check_url_existence(cartoon_lines, channel_address):
                cartoon_lines.append(process_name_string(line.strip()))
            elif channel_name in traditional_opera_dictionary and check_url_existence(traditional_opera_lines, channel_address):
                traditional_opera_lines.append(process_name_string(line.strip()))
            elif channel_name in commentary_dictionary and check_url_existence(commentary_lines, channel_address):
                commentary_lines.append(process_name_string(line.strip()))
            elif channel_name in spring_festival_gala_dictionary and check_url_existence(spring_festival_gala_lines, channel_address):
                spring_festival_gala_lines.append(process_name_string(line.strip()))
            elif channel_name in variety_dictionary and check_url_existence(variety_lines, channel_address):
                variety_lines.append(process_name_string(line.strip()))
            elif channel_name in music_dictionary and check_url_existence(music_lines, channel_address):
                music_lines.append(process_name_string(line.strip()))
            elif channel_name in game_dictionary and check_url_existence(game_lines, channel_address):
                game_lines.append(process_name_string(line.strip()))
            elif channel_name in radio_dictionary and check_url_existence(radio_lines, channel_address):
                radio_lines.append(process_name_string(line.strip()))
            elif channel_name in zhejiang_dictionary and check_url_existence(zhejiang_lines, channel_address):
                zhejiang_lines.append(process_name_string(line.strip()))
            elif channel_name in jiangsu_dictionary and check_url_existence(jiangsu_lines, channel_address):
                jiangsu_lines.append(process_name_string(line.strip()))
            elif channel_name in guangdong_dictionary and check_url_existence(guangdong_lines, channel_address):
                guangdong_lines.append(process_name_string(line.strip()))
            elif channel_name in hunan_dictionary and check_url_existence(hunan_lines, channel_address):
                hunan_lines.append(process_name_string(line.strip()))
            elif channel_name in hubei_dictionary and check_url_existence(hubei_lines, channel_address):
                hubei_lines.append(process_name_string(line.strip()))
            elif channel_name in anhui_dictionary and check_url_existence(anhui_lines, channel_address):
                anhui_lines.append(process_name_string(line.strip()))
            elif channel_name in hainan_dictionary and check_url_existence(hainan_lines, channel_address):
                hainan_lines.append(process_name_string(line.strip()))
            elif channel_name in neimenggu_dictionary and check_url_existence(neimenggu_lines, channel_address):
                neimenggu_lines.append(process_name_string(line.strip()))
            elif channel_name in liaoning_dictionary and check_url_existence(liaoning_lines, channel_address):
                liaoning_lines.append(process_name_string(line.strip()))
            elif channel_name in shaanxi_dictionary and check_url_existence(shaanxi_lines, channel_address):
                shaanxi_lines.append(process_name_string(line.strip()))
            elif channel_name in shanxi_dictionary and check_url_existence(shanxi_lines, channel_address):
                shanxi_lines.append(process_name_string(line.strip()))
            elif channel_name in shandong_dictionary and check_url_existence(shandong_lines, channel_address):
                shandong_lines.append(process_name_string(line.strip()))
            elif channel_name in yunnan_dictionary and check_url_existence(yunnan_lines, channel_address):
                yunnan_lines.append(process_name_string(line.strip()))
            elif channel_name in beijing_dictionary and check_url_existence(beijing_lines, channel_address):
                beijing_lines.append(process_name_string(line.strip()))
            elif channel_name in chongqing_dictionary and check_url_existence(chongqing_lines, channel_address):
                chongqing_lines.append(process_name_string(line.strip()))
            elif channel_name in fujian_dictionary and check_url_existence(fujian_lines, channel_address):
                fujian_lines.append(process_name_string(line.strip()))
            elif channel_name in gansu_dictionary and check_url_existence(gansu_lines, channel_address):
                gansu_lines.append(process_name_string(line.strip()))
            elif channel_name in guangxi_dictionary and check_url_existence(guangxi_lines, channel_address):
                guangxi_lines.append(process_name_string(line.strip()))
            elif channel_name in guizhou_dictionary and check_url_existence(guizhou_lines, channel_address):
                guizhou_lines.append(process_name_string(line.strip()))
            elif channel_name in hebei_dictionary and check_url_existence(hebei_lines, channel_address):
                hebei_lines.append(process_name_string(line.strip()))
            elif channel_name in henan_dictionary and check_url_existence(henan_lines, channel_address):
                henan_lines.append(process_name_string(line.strip()))
            elif channel_name in heilongjiang_dictionary and check_url_existence(heilongjiang_lines, channel_address):
                heilongjiang_lines.append(process_name_string(line.strip()))
            elif channel_name in jilin_dictionary and check_url_existence(jilin_lines, channel_address):
                jilin_lines.append(process_name_string(line.strip()))
            elif channel_name in jiangxi_dictionary and check_url_existence(jiangxi_lines, channel_address):
                jiangxi_lines.append(process_name_string(line.strip()))
            elif channel_name in ningxia_dictionary and check_url_existence(ningxia_lines, channel_address):
                ningxia_lines.append(process_name_string(line.strip()))
            elif channel_name in qinghai_dictionary and check_url_existence(qinghai_lines, channel_address):
                qinghai_lines.append(process_name_string(line.strip()))
            elif channel_name in sichuan_dictionary and check_url_existence(sichuan_lines, channel_address):
                sichuan_lines.append(process_name_string(line.strip()))
            elif channel_name in tianjin_dictionary and check_url_existence(tianjin_lines, channel_address):
                tianjin_lines.append(process_name_string(line.strip()))
            elif channel_name in xinjiang_dictionary and check_url_existence(xinjiang_lines, channel_address):
                xinjiang_lines.append(process_name_string(line.strip()))
            elif channel_name in xizang_dictionary and check_url_existence(xizang_lines, channel_address):  # 修正
                xizang_lines.append(process_name_string(line.strip()))
            elif channel_name in camera_dictionary and check_url_existence(camera_lines, channel_address):
                camera_lines.append(process_name_string(line.strip()))
            elif channel_name in china_dictionary and check_url_existence(china_lines, channel_address):
                china_lines.append(process_name_string(line.strip()))
            elif channel_name in news_dictionary and check_url_existence(news_lines, channel_address):
                news_lines.append(process_name_string(line.strip()))
            elif channel_name in food_dictionary and check_url_existence(food_lines, channel_address):
                food_lines.append(process_name_string(line.strip()))
            elif channel_name in travel_dictionary and check_url_existence(travel_lines, channel_address):
                travel_lines.append(process_name_string(line.strip()))
            elif channel_name in health_dictionary and check_url_existence(health_lines, channel_address):
                health_lines.append(process_name_string(line.strip()))
            elif channel_name in finance_dictionary and check_url_existence(finance_lines, channel_address):
                finance_lines.append(process_name_string(line.strip()))
            elif channel_name in shopping_dictionary and check_url_existence(shopping_lines, channel_address):
                shopping_lines.append(process_name_string(line.strip()))
            elif channel_name in huya_dictionary and check_url_existence(huya_lines, channel_address):
                huya_lines.append(process_name_string(line.strip()))
            elif channel_name in douyu_dictionary and check_url_existence(douyu_lines, channel_address):
                douyu_lines.append(process_name_string(line.strip()))
            elif channel_name in digital_dictionary and check_url_existence(digital_lines, channel_address):
                digital_lines.append(process_name_string(line.strip()))
            elif channel_name in favorite_dictionary and check_url_existence(favorite_lines, channel_address):
                favorite_lines.append(process_name_string(line.strip()))
            else:
                if channel_address not in other_lines_url:
                    other_lines_url.append(channel_address)
                    other_lines.append(line.strip())

# 随机获取User-Agent,备用 
def get_random_user_agent():
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36",
    ]
    return random.choice(USER_AGENTS)

def process_url(url):
    try:
        other_lines.append("◆◆◆　"+url)  # 存入other_lines便于check 2024-08-02 10:41
        
        # 创建一个请求对象并添加自定义header
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3')

        # 打开URL并读取内容
        with urllib.request.urlopen(req) as response:
            # 以二进制方式读取数据
            data = response.read()
            # 将二进制数据解码为字符串
            text = data.decode('utf-8')
            text = text.strip()
            # channel_name=""
            # channel_address=""

            #处理m3u和m3u8，提取channel_name和channel_address
            #增加扩展名非m3u和m3u8为扩展名的m3u格式            
            is_m3u = text.startswith("#EXTM3U") or text.startswith("#EXTINF")
            if get_url_file_extension(url)==".m3u" or get_url_file_extension(url)==".m3u8" or is_m3u:
                text=convert_m3u_to_txt(text)

            # 逐行处理内容
            lines = text.split('\n')
            print(f"行数: {len(lines)}")
            for line in lines:
                if  "#genre#" not in line and "," in line and "://" in line and "tvbus://" not in line and "/udp/" not in line:
                    # tvbus://剔除tvbus
                    # /udp/剔除组播
                    # 拆分成频道名和URL部分
                    channel_name, channel_address = line.split(',', 1)
                    #需要加处理带#号源=予加速源
                    if "#" not in channel_address:
                        process_channel_line(line) # 如果没有井号，则照常按照每行规则进行分发
                    else: 
                        # 如果有“#”号，则根据“#”号分隔
                        url_list = channel_address.split('#')
                        for channel_url in url_list:
                            newline=f'{channel_name},{channel_url}'
                            process_channel_line(newline)

            other_lines.append('\n') #每个url处理完成后，在other_lines加个回车 2024-08-02 10:46

    except Exception as e:
        print(f"处理URL时发生错误：{e}")


current_directory = os.getcwd()  #准备读取txt

# ========= 频道字典文件读取 =========

# 读取核心频道字典（使用您的自定义路径）
yangshi_dictionary = read_txt_to_array('assets/livesource/主频道/CCTV.txt')
weishi_dictionary = read_txt_to_array('assets/livesource/主频道/卫视.txt')
sports_dictionary = read_txt_to_array('assets/livesource/主频道/体育.txt')
tyss_dictionary = read_txt_to_array('assets/livesource/主频道/体育赛事.txt')
mgss_dictionary = read_txt_to_array('assets/livesource/主频道/咪咕赛事.txt')
movie_dictionary = read_txt_to_array('assets/livesource/主频道/电影.txt')
tv_drama_dictionary = read_txt_to_array('assets/livesource/主频道/电视剧.txt')
shanghai_dictionary = read_txt_to_array('assets/livesource/地方台/上海.txt')
hongkong_dictionary = read_txt_to_array('assets/livesource/地方台/香港.txt')
macau_dictionary = read_txt_to_array('assets/livesource/地方台/澳门.txt')
minnan_dictionary = read_txt_to_array('assets/livesource/地方台/闽南.txt')
international_dictionary = read_txt_to_array('assets/livesource/主频道/国际.txt')
documentary_dictionary = read_txt_to_array('assets/livesource/主频道/纪录片.txt')
cartoon_dictionary = read_txt_to_array('assets/livesource/主频道/动画片.txt')
traditional_opera_dictionary = read_txt_to_array('assets/livesource/主频道/戏曲.txt')
commentary_dictionary = read_txt_to_array('assets/livesource/主频道/解说.txt')
spring_festival_gala_dictionary = read_txt_to_array('assets/livesource/主频道/春晚.txt')
variety_dictionary = read_txt_to_array('assets/livesource/主频道/综艺.txt')
music_dictionary = read_txt_to_array('assets/livesource/主频道/音乐.txt')
game_dictionary = read_txt_to_array('assets/livesource/主频道/游戏.txt')
radio_dictionary = read_txt_to_array('assets/livesource/主频道/收音机.txt')

# 新增缺失的字典
china_dictionary = read_txt_to_array('assets/livesource/主频道/中国.txt')
news_dictionary = read_txt_to_array('assets/livesource/主频道/新闻.txt')
food_dictionary = read_txt_to_array('assets/livesource/主频道/美食.txt')
travel_dictionary = read_txt_to_array('assets/livesource/主频道/旅游.txt')
health_dictionary = read_txt_to_array('assets/livesource/主频道/健康.txt')
finance_dictionary = read_txt_to_array('assets/livesource/主频道/财经.txt')
shopping_dictionary = read_txt_to_array('assets/livesource/主频道/购物.txt')
huya_dictionary = read_txt_to_array('assets/livesource/主频道/虎牙.txt')
douyu_dictionary = read_txt_to_array('assets/livesource/主频道/斗鱼.txt')
digital_dictionary = read_txt_to_array('assets/livesource/主频道/数字.txt')
favorite_dictionary = read_txt_to_array('assets/livesource/主频道/收藏频道.txt')

# 省级地方台字典
zhejiang_dictionary = read_txt_to_array('assets/livesource/地方台/浙江.txt')
jiangsu_dictionary = read_txt_to_array('assets/livesource/地方台/江苏.txt')
guangdong_dictionary = read_txt_to_array('assets/livesource/地方台/广东.txt')
hunan_dictionary = read_txt_to_array('assets/livesource/地方台/湖南.txt')
hubei_dictionary = read_txt_to_array('assets/livesource/地方台/湖北.txt')
anhui_dictionary = read_txt_to_array('assets/livesource/地方台/安徽.txt')
hainan_dictionary = read_txt_to_array('assets/livesource/地方台/海南.txt')
neimenggu_dictionary = read_txt_to_array('assets/livesource/地方台/内蒙.txt')
liaoning_dictionary = read_txt_to_array('assets/livesource/地方台/辽宁.txt')
shaanxi_dictionary = read_txt_to_array('assets/livesource/地方台/陕西.txt')
shanxi_dictionary = read_txt_to_array('assets/livesource/地方台/山西.txt')
shandong_dictionary = read_txt_to_array('assets/livesource/地方台/山东.txt')
yunnan_dictionary = read_txt_to_array('assets/livesource/地方台/云南.txt')
beijing_dictionary = read_txt_to_array('assets/livesource/地方台/北京.txt')
chongqing_dictionary = read_txt_to_array('assets/livesource/地方台/重庆.txt')
fujian_dictionary = read_txt_to_array('assets/livesource/地方台/福建.txt')
gansu_dictionary = read_txt_to_array('assets/livesource/地方台/甘肃.txt')
guangxi_dictionary = read_txt_to_array('assets/livesource/地方台/广西.txt')
guizhou_dictionary = read_txt_to_array('assets/livesource/地方台/贵州.txt')
hebei_dictionary = read_txt_to_array('assets/livesource/地方台/河北.txt')
henan_dictionary = read_txt_to_array('assets/livesource/地方台/河南.txt')
heilongjiang_dictionary = read_txt_to_array('assets/livesource/地方台/黑龙江.txt')
jilin_dictionary = read_txt_to_array('assets/livesource/地方台/吉林.txt')
jiangxi_dictionary = read_txt_to_array('assets/livesource/地方台/江西.txt')
ningxia_dictionary = read_txt_to_array('assets/livesource/地方台/宁夏.txt')
qinghai_dictionary = read_txt_to_array('assets/livesource/地方台/青海.txt')
sichuan_dictionary = read_txt_to_array('assets/livesource/地方台/四川.txt')
tianjin_dictionary = read_txt_to_array('assets/livesource/地方台/天津.txt')
xinjiang_dictionary = read_txt_to_array('assets/livesource/地方台/新疆.txt')
xizang_dictionary = read_txt_to_array('assets/livesource/地方台/西藏.txt')  # 新增

# 其他字典
camera_dictionary = read_txt_to_array('assets/livesource/主频道/直播中国.txt')

#读取纠错频道名称方法
def load_corrections_name(filename):
    corrections = {}
    with open(filename, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): #跳过空行
                continue
            parts = line.strip().split(',')
            correct_name = parts[0]
            for name in parts[1:]:
                corrections[name] = correct_name
    return corrections

#读取纠错文件
corrections_name = load_corrections_name('assets/livesource/corrections_name.txt')

#纠错频道名称
#correct_name_data(corrections_name,xxxx)
def correct_name_data(corrections, data):
    corrected_data = []
    for line in data:
        line = line.strip()
        if ',' not in line:
            # 行格式错误：跳过或记录
            continue

        name, url = line.split(',', 1)

        # 空 name 处理（可选）
        if name in corrections and name != corrections[name]:
            name = corrections[name]

        corrected_data.append(f"{name},{url}")
    return corrected_data


def sort_data(order, data):
    # 创建一个字典来存储每行数据的索引
    order_dict = {name: i for i, name in enumerate(order)}
    
    # 定义一个排序键函数，处理不在 order_dict 中的字符串
    def sort_key(line):
        name = line.split(',')[0]
        return order_dict.get(name, len(order))
    
    # 按照 order 中的顺序对数据进行排序
    sorted_data = sorted(data, key=sort_key)
    return sorted_data





# 定义
urls = read_txt_to_array('assets/livesource/urls-daily.txt')
# 处理
for url in urls:
    if url.startswith("http"):
        if "{MMdd}" in url: #特别处理113
            current_date_str = datetime.now().strftime("%m%d")
            url=url.replace("{MMdd}", current_date_str)

        if "{MMdd-1}" in url: #特别处理113
            yesterday_date_str = (datetime.now() - timedelta(days=1)).strftime("%m%d")
            url=url.replace("{MMdd-1}", yesterday_date_str)
            
        print(f"处理URL: {url}")
        process_url(url)



# 定义一个函数，提取每行中逗号前面的数字部分作为排序的依据
def extract_number(s):
    num_str = s.split(',')[0].split('-')[1]  # 提取逗号前面的数字部分
    numbers = re.findall(r'\d+', num_str)   #因为有+和K
    return int(numbers[-1]) if numbers else 999
# 定义一个自定义排序函数
def custom_sort(s):
    if "CCTV-4K" in s:
        return 2  # 将包含 "4K" 的字符串排在后面
    elif "CCTV-8K" in s:
        return 3  # 将包含 "8K" 的字符串排在后面 
    elif "(4K)" in s:
        return 1  # 将包含 " (4K)" 的字符串排在后面
    else:
        return 0  # 其他字符串保持原顺序



#读取whitelist,把高响应源从白名单中抽出加入merged_output。
print(f"ADD whitelist_auto.txt")
whitelist_auto_lines=read_txt_to_array('assets/livesource/blacklist/whitelist_auto.txt') #
for whitelist_line in whitelist_auto_lines:
    if  "#genre#" not in whitelist_line and "," in whitelist_line and "://" in whitelist_line:
        whitelist_parts = whitelist_line.split(",")
        try:
            response_time = float(whitelist_parts[0].replace("ms", ""))
        except ValueError:
            print(f"response_time转换失败: {whitelist_line}")
            response_time = 60000  # 单位毫秒，转换失败给个60秒
        if response_time < 2000:  #2s以内的高响应源
            process_channel_line(",".join(whitelist_parts[1:]))


# def get_http_response(url):
#     req = urllib.request.Request(url)
#     req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3')

#     # 打开URL并读取内容
#     with urllib.request.urlopen(req) as response:
#         # 以二进制方式读取数据
#         data = response.read()
#         # 将二进制数据解码为字符串
#         text = data.decode('utf-8')
#     return text
def get_http_response(url, timeout=8, retries=2, backoff_factor=1.0):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
    }
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                data = response.read()
                return data.decode('utf-8')
        except urllib.error.HTTPError as e:
            print(f"[HTTPError] Code: {e.code}, URL: {url}")
            break  # 一般来说 HTTP 错误不会在重试中恢复
        except urllib.error.URLError as e:
            print(f"[URLError] Reason: {e.reason}, Attempt: {attempt + 1}")
        except socket.timeout:
            print(f"[Timeout] URL: {url}, Attempt: {attempt + 1}")
        except Exception as e:
            print(f"[Exception] {type(e).__name__}: {e}, Attempt: {attempt + 1}")
        
        # 等待一段时间后重试
        if attempt < retries - 1:
            time.sleep(backoff_factor * (2 ** attempt))
    
    return None  # 所有尝试失败后返回 None

# 将日期统一格式化为 MM-DD格式
def normalize_date_to_md(text):
    text = text.strip()

    # 定义替换函数：确保后面有一个空格
    def format_md(m):
        month = int(m.group(1))
        day = int(m.group(2))
        after = m.group(3) or ''
        # 如果后面不是空格开头，就加空格
        if not after.startswith(' '):
            after = ' ' + after
        return f"{month:02d}-{day:02d}{after}"

    # MM/DD 或 M/D
    text = re.sub(r'^0?(\d{1,2})/0?(\d{1,2})(.*)', format_md, text)

    # YYYY-MM-DD 或类似形式
    text = re.sub(r'^\d{4}-0?(\d{1,2})-0?(\d{1,2})(.*)', format_md, text)

    # 中文 M月D日
    text = re.sub(r'^0?(\d{1,2})月0?(\d{1,2})日(.*)', format_md, text)

    return text

# 将日期统一格式化为 MM-DD格式
normalized_tyss_lines = [normalize_date_to_md(s) for s in tyss_lines]

#AKTV#
aktv_lines = [] #AKTV
aktv_url = "https://aktv.space/live.m3u" #AKTV

aktv_text = get_http_response(aktv_url)
if aktv_text:
    print("AKTV成功获取内容")
    aktv_text = convert_m3u_to_txt(aktv_text)
    aktv_lines = aktv_text.strip().split('\n')
else:
    print("AKTV请求失败，从本地获取！")
    aktv_lines = read_txt_to_array('专区/AKTV.txt')
#AKTV# ["💓AKTV🚀📶,#genre#"] + aktv_lines + ['\n'] + \

#过滤掉特定关键词的行
#keywords_to_exclude = ["玉玉软件", "榴芒电视","公众号"]
def filter_lines(lines, exclude_keywords):
    """
    过滤掉包含任一关键字的行
    :param lines: 原始字符串数组
    :param exclude_keywords: 需要剔除的关键词列表
    :return: 过滤后的新列表
    """
    return [line for line in lines if not any(keyword in line for keyword in exclude_keywords)]


def generate_playlist_html(data_list, output_file='playlist.html'):
    html_head = '''
    <!DOCTYPE html>
    <html lang="zh">
    <head>
        <meta charset="UTF-8">        
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6061710286208572"
     crossorigin="anonymous"></script>
        <!-- Setup Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-BS1Z4F5BDN"></script>
        <script> 
        window.dataLayer = window.dataLayer || []; 
        function gtag(){dataLayer.push(arguments);} 
        gtag('js', new Date()); 
        gtag('config', 'G-BS1Z4F5BDN'); 
        </script>
        <title>最新体育赛事</title>
        <style>
            body { font-family: sans-serif; padding: 20px; background: #f9f9f9; }
            .item { margin-bottom: 20px; padding: 12px; background: #fff; border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.06); }
            .title { font-weight: bold; font-size: 1.1em; color: #333; margin-bottom: 5px; }
            .url-wrapper { display: flex; align-items: center; gap: 10px; }
            .url {
                max-width: 80%;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                font-size: 0.9em;
                color: #555;
                background: #f0f0f0;
                padding: 6px;
                border-radius: 4px;
                flex-grow: 1;
            }
            .copy-btn {
                background-color: #007BFF;
                border: none;
                color: white;
                padding: 6px 10px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 0.8em;
            }
            .copy-btn:hover {
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
    <h2>📋 最新体育赛事列表</h2>
    '''

    html_body = ''
    for idx, entry in enumerate(data_list):
        if ',' not in entry:
            continue
        info, url = entry.split(',', 1)
        url_id = f"url_{idx}"
        html_body += f'''
        <div class="item">
            <div class="title">🕒 {info}</div>
            <div class="url-wrapper">
                <div class="url" id="{url_id}">{url}</div>
                <button class="copy-btn" onclick="copyToClipboard('{url_id}')">复制</button>
            </div>
        </div>
        '''

    html_tail = '''
    <script>
        function copyToClipboard(id) {
            const el = document.getElementById(id);
            const text = el.textContent;
            navigator.clipboard.writeText(text).then(() => {
                alert("已复制链接！");
            }).catch(err => {
                alert("复制失败: " + err);
            });
        }
    </script>
    </body>
    </html>
    '''

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_head + html_body + html_tail)
    print(f"✅ 网页已生成：{output_file}")

# 体育赛事专用排序, 数字开头倒序排在上面，其他升序排在下面。
def custom_tyss_sort(lines):
    digit_prefix = []
    others = []

    for line in lines:
        # 拆分出名称部分（逗号前部分），用于判断是否以数字开头
        name_part = line.split(',')[0].strip()
        if name_part and name_part[0].isdigit():
            digit_prefix.append(line)
        else:
            others.append(line)

    # 分别排序
    digit_prefix_sorted = sorted(digit_prefix, reverse=True)
    others_sorted = sorted(others)

    return digit_prefix_sorted + others_sorted

# 过滤txt中体育赛事
keywords_to_exclude_tiyu_txt = ["玉玉软件", "榴芒电视","公众号","麻豆","「回看」"]
normalized_tyss_lines = filter_lines(normalized_tyss_lines, keywords_to_exclude_tiyu_txt)
normalized_tyss_lines = custom_tyss_sort(set(normalized_tyss_lines))

# 过滤tiyu页面中体育赛事
keywords_to_exclude_tiyu = ["玉玉软件", "榴芒电视","公众号","咪视通","麻豆","「回看」"]
filtered_tyss_lines = filter_lines(normalized_tyss_lines, keywords_to_exclude_tiyu)
generate_playlist_html(filtered_tyss_lines, 'tiyu.html')

# 随机取得URL
def get_random_url(file_path):
    urls = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            # 查找逗号后面的部分，即URL
            url = line.strip().split(',')[-1]
            urls.append(url)    
    # 随机返回一个URL
    return random.choice(urls) if urls else None

# 生成今日推荐信息
utc_time = datetime.now(timezone.utc)
beijing_time = utc_time + timedelta(hours=8)
formatted_time = beijing_time.strftime("%Y%m%d %H:%M:%S")

MTV1 = "💯推荐," + get_random_url('assets/livesource/手工区/今日推荐.txt')
MTV2 = "🤫低调," + get_random_url('assets/livesource/手工区/今日推荐.txt')
MTV3 = "🟢使用," + get_random_url('assets/livesource/手工区/今日推荐.txt')
MTV4 = "⚠️禁止," + get_random_url('assets/livesource/手工区/今日推荐.txt')
MTV5 = "🚫贩卖," + get_random_url('assets/livesource/手工区/今日推荐.txt')

about_video1 = "https://gitee.com/xiaoran67/update/raw/master/assets/livesource/about1080p.mp4"
about_video2 = "https://gitlab.com/xiaoran67/update/-/raw/main/assets/livesource/about1080p.mp4"

version = formatted_time + "," + get_random_url('assets/livesource/手工区/今日推台.txt')
about = "👨潇然," + get_random_url('assets/livesource/手工区/今日推台.txt')

# ========= 手工区数据补充 =========

print(f"处理手工区...")
zhejiang_lines = zhejiang_lines + read_txt_to_array('assets/livesource/手工区/浙江频道.txt')
guangdong_lines = guangdong_lines + read_txt_to_array('assets/livesource/手工区/广东频道.txt')
hubei_lines = hubei_lines + read_txt_to_array('assets/livesource/手工区/湖北频道.txt')
shanghai_lines = shanghai_lines + read_txt_to_array('assets/livesource/手工区/上海频道.txt')
jiangsu_lines = jiangsu_lines + read_txt_to_array('assets/livesource/手工区/江苏频道.txt')

# ========= 生成最终播放列表文件 =========

# 完整版播放列表（包含所有分类）
all_lines_full = ["🌐央视频道,#genre#"] + sort_data(yangshi_dictionary,correct_name_data(corrections_name,yangshi_lines)) + ['\n'] + \
        ["📡卫视频道,#genre#"] + sort_data(weishi_dictionary,correct_name_data(corrections_name,weishi_lines)) + ['\n'] + \
        ["🏛️北京频道,#genre#"] + sort_data(beijing_dictionary,correct_name_data(corrections_name,beijing_lines)) + ['\n'] + \
        ["🏙️上海频道,#genre#"] + sort_data(shanghai_dictionary,correct_name_data(corrections_name,shanghai_lines)) + ['\n'] + \
        ["🐯广东频道,#genre#"] + sort_data(guangdong_dictionary,correct_name_data(corrections_name,guangdong_lines)) + ['\n'] + \
        ["🎐江苏频道,#genre#"] + sort_data(jiangsu_dictionary,correct_name_data(corrections_name,jiangsu_lines)) + ['\n'] + \
        ["🧵浙江频道,#genre#"] + sort_data(zhejiang_dictionary,correct_name_data(corrections_name,zhejiang_lines)) + ['\n'] + \
        ["⛰️山东频道,#genre#"] + sort_data(shandong_dictionary,correct_name_data(corrections_name,shandong_lines)) + ['\n'] + \
        ["🐼四川频道,#genre#"] + sort_data(sichuan_dictionary,correct_name_data(corrections_name,sichuan_lines)) + ['\n'] + \
        ["🐘河南频道,#genre#"] + sort_data(henan_dictionary,correct_name_data(corrections_name,henan_lines)) + ['\n'] + \
        ["🌶️湖南频道,#genre#"] + sort_data(hunan_dictionary,correct_name_data(corrections_name,hunan_lines)) + ['\n'] + \
        ["🏞️重庆频道,#genre#"] + sort_data(chongqing_dictionary,correct_name_data(corrections_name,chongqing_lines)) + ['\n'] + \
        ["🚢天津频道,#genre#"] + sort_data(tianjin_dictionary,correct_name_data(corrections_name,tianjin_lines)) + ['\n'] + \
        ["🏯湖北频道,#genre#"] + sort_data(hubei_dictionary,correct_name_data(corrections_name,hubei_lines)) + ['\n'] + \
        ["🌾安徽频道,#genre#"] + sort_data(anhui_dictionary,correct_name_data(corrections_name,anhui_lines)) + ['\n'] + \
        ["🌊福建频道,#genre#"] + sort_data(fujian_dictionary,correct_name_data(corrections_name,fujian_lines)) + ['\n'] + \
        ["⛰️辽宁频道,#genre#"] + sort_data(liaoning_dictionary,correct_name_data(corrections_name,liaoning_lines)) + ['\n'] + \
        ["🔥陕西频道,#genre#"] + sort_data(shaanxi_dictionary,correct_name_data(corrections_name,shaanxi_lines)) + ['\n'] + \
        ["⛩️河北频道,#genre#"] + sort_data(hebei_dictionary,correct_name_data(corrections_name,hebei_lines)) + ['\n'] + \
        ["🔥江西频道,#genre#"] + sort_data(jiangxi_dictionary,correct_name_data(corrections_name,jiangxi_lines)) + ['\n'] + \
        ["💃广西频道,#genre#"] + sort_data(guangxi_dictionary,correct_name_data(corrections_name,guangxi_lines)) + ['\n'] + \
        ["☁️云南频道,#genre#"] + sort_data(yunnan_dictionary,correct_name_data(corrections_name,yunnan_lines)) + ['\n'] + \
        ["🏮山西频道,#genre#"] + sort_data(shanxi_dictionary,correct_name_data(corrections_name,shanxi_lines)) + ['\n'] + \
        ["🐻黑·龙·江,#genre#"] + sort_data(heilongjiang_dictionary,correct_name_data(corrections_name,heilongjiang_lines)) + ['\n'] + \
        ["🎎吉林频道,#genre#"] + sort_data(jilin_dictionary,correct_name_data(corrections_name,jilin_lines)) + ['\n'] + \
        ["⛰️贵州频道,#genre#"] + sort_data(guizhou_dictionary,correct_name_data(corrections_name,guizhou_lines)) + ['\n'] + \
        ["🐫甘肃频道,#genre#"] + sort_data(gansu_dictionary,correct_name_data(corrections_name,gansu_lines)) + ['\n'] + \
        ["🐮内·蒙·古,#genre#"] + sort_data(neimenggu_dictionary,correct_name_data(corrections_name,neimenggu_lines)) + ['\n'] + \
        ["🍇新疆频道,#genre#"] + sort_data(xinjiang_dictionary,correct_name_data(corrections_name,xinjiang_lines)) + ['\n'] + \
        ["🏝️海南频道,#genre#"] + sort_data(hainan_dictionary,correct_name_data(corrections_name,hainan_lines)) + ['\n'] + \
        ["🕌宁夏频道,#genre#"] + sort_data(ningxia_dictionary,correct_name_data(corrections_name,ningxia_lines)) + ['\n'] + \
        ["🐑青海频道,#genre#"] + sort_data(qinghai_dictionary,correct_name_data(corrections_name,qinghai_lines)) + ['\n'] + \
        ["🐐西藏频道,#genre#"] + sort_data(xizang_dictionary,correct_name_data(corrections_name,xizang_lines)) + ['\n'] + \
        ["🇭🇰香港频道,#genre#"] + sort_data(hongkong_dictionary,correct_name_data(corrections_name,hongkong_lines)) + ['\n'] + \
        ["🇲🇴澳门频道,#genre#"] + sort_data(macau_dictionary,correct_name_data(corrections_name,macau_lines)) + ['\n'] + \
        ["📺闽南频道,#genre#"] + sort_data(minnan_dictionary,correct_name_data(corrections_name,minnan_lines)) + ['\n'] + \
        ["🔢数字频道,#genre#"] + sort_data(digital_dictionary,correct_name_data(corrections_name,digital_lines)) + ['\n'] + \
        ["🎬电影频道,#genre#"] + sort_data(movie_dictionary,correct_name_data(corrections_name,movie_lines)) + ['\n'] + \
        ["📺电·视·剧,#genre#"] + sort_data(tv_drama_dictionary,correct_name_data(corrections_name,tv_drama_lines)) + ['\n'] + \
        ["🎥纪·录·片,#genre#"] + sort_data(documentary_dictionary,correct_name_data(corrections_name,documentary_lines)) + ['\n'] + \
        ["🐱动·画·片,#genre#"] + sort_data(cartoon_dictionary,correct_name_data(corrections_name,cartoon_lines)) + ['\n'] + \
        ["📻收·音·机,#genre#"] + sort_data(radio_dictionary,correct_name_data(corrections_name,radio_lines)) + ['\n'] + \
        ["🎭综艺频道,#genre#"] + sort_data(variety_dictionary,correct_name_data(corrections_name,variety_lines)) + ['\n'] + \
        ["🐯虎牙直播,#genre#"] + sort_data(huya_dictionary,correct_name_data(corrections_name,huya_lines)) + ['\n'] + \
        ["🐠斗鱼直播,#genre#"] + sort_data(douyu_dictionary,correct_name_data(corrections_name,douyu_lines)) + ['\n'] + \
        ["🎤解说频道,#genre#"] + sort_data(commentary_dictionary,correct_name_data(corrections_name,commentary_lines)) + ['\n'] + \
        ["🎵音乐频道,#genre#"] + sort_data(music_dictionary,correct_name_data(corrections_name,music_lines)) + ['\n'] + \
        ["🍜美食频道,#genre#"] + sort_data(food_dictionary,correct_name_data(corrections_name,food_lines)) + ['\n'] + \
        ["✈️旅游频道,#genre#"] + sort_data(travel_dictionary,correct_name_data(corrections_name,travel_lines)) + ['\n'] + \
        ["🏥健康频道,#genre#"] + sort_data(health_dictionary,correct_name_data(corrections_name,health_lines)) + ['\n'] + \
        ["💰财经频道,#genre#"] + sort_data(finance_dictionary,correct_name_data(corrections_name,finance_lines)) + ['\n'] + \
        ["🛍️购物频道,#genre#"] + sort_data(shopping_dictionary,correct_name_data(corrections_name,shopping_lines)) + ['\n'] + \
        ["🎮游戏频道,#genre#"] + sort_data(game_dictionary,correct_name_data(corrections_name,game_lines)) + ['\n'] + \
        ["📰新闻频道,#genre#"] + sort_data(news_dictionary,correct_name_data(corrections_name,news_lines)) + ['\n'] + \
        ["🇨🇳中国综合,#genre#"] + sort_data(china_dictionary,correct_name_data(corrections_name,china_lines)) + ['\n'] + \
        ["🌐国际频道,#genre#"] + sort_data(international_dictionary,correct_name_data(corrections_name,international_lines)) + ['\n'] + \
        ["⚽体育频道,#genre#"] + sort_data(sports_dictionary,correct_name_data(corrections_name,sports_lines)) + ['\n'] + \
        ["🏆体育赛事,#genre#"] + normalized_tyss_lines + ['\n'] + \
        ["🏈咪咕赛事,#genre#"] + sorted(set(mgss_lines)) + ['\n'] + \
        ["🎭戏曲频道,#genre#"] + sort_data(traditional_opera_dictionary,correct_name_data(corrections_name,traditional_opera_lines)) + ['\n'] + \
        ["🧨春晚频道,#genre#"] + sort_data(spring_festival_gala_dictionary,correct_name_data(corrections_name,spring_festival_gala_lines)) + ['\n'] + \
        ["🏞️景区直播,#genre#"] + sort_data(camera_dictionary,correct_name_data(corrections_name,camera_lines)) + ['\n'] + \
        ["⭐收藏频道,#genre#"] + sort_data(favorite_dictionary,correct_name_data(corrections_name,favorite_lines)) + ['\n'] + \
        ["📦其他频道,#genre#"] + sorted(set(other_lines)) + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + [MTV1] + [MTV2] + [MTV3] + [MTV4] + [MTV5] + ['\n']

# 精简版播放列表（只包含核心频道）
all_lines_lite = ["🌐央视频道,#genre#"] + sort_data(yangshi_dictionary,correct_name_data(corrections_name,yangshi_lines)) + ['\n'] + \
        ["📡卫视频道,#genre#"] + sort_data(weishi_dictionary,correct_name_data(corrections_name,weishi_lines)) + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + [MTV1] + [MTV2] + [MTV3] + [MTV4] + [MTV5] + ['\n']

# 定制版播放列表
all_lines_custom = [
        "🌐央视频道,#genre#"] + sort_data(yangshi_dictionary, correct_name_data(corrections_name, yangshi_lines)) + ['\n'] + \
        ["📡卫视频道,#genre#"] + sort_data(weishi_dictionary, correct_name_data(corrections_name, weishi_lines)) + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + [MTV1] + [MTV2] + [MTV3] + [MTV4] + [MTV5] + ['\n']


# 文件路径定义
output_full = "output/full.txt"
output_lite = "output/lite.txt"
output_custom = "output/custom.txt"
output_others = "output/others.txt"

try:
    # 写入完整版
    with open(output_full, 'w', encoding='utf-8') as f:
        for line in all_lines_full:
            f.write(line + '\n')
    print(f"完整版已保存到文件: {output_full}")
    
    # 写入精简版
    with open(output_lite, 'w', encoding='utf-8') as f:
        for line in all_lines_lite:
            f.write(line + '\n')
    print(f"精简版已保存到文件: {output_lite}")
    
    # 写入定制版
    with open(output_custom, 'w', encoding='utf-8') as f:
        for line in all_lines_custom:
            f.write(line + '\n')
    print(f"定制版已保存到文件: {output_custom}")
    
    # 写入其他频道
    with open(output_others, 'w', encoding='utf-8') as f:
        for line in other_lines:
            f.write(line + '\n')
    print(f"其他频道已保存到文件: {output_others}")

except Exception as e:
    print(f"保存文件时发生错误：{e}")

channels_logos=read_txt_to_array('assets/livesource/logo.txt') #读入logo库
def get_logo_by_channel_name(channel_name):
    
    # 遍历数组查找频道名称
    for line in channels_logos:
        # 去除首尾空白并检查是否为空行(没有这个判断logo中如果出现空行会出错)
        if not line.strip():
            continue
        name, url = line.split(',')
        if name == channel_name:
            return url
    return None



def make_m3u(txt_file, m3u_file):
    try:
        output_text = '#EXTM3U x-tvg-url="https://live.fanmingming.cn/e.xml"\n'

        with open(txt_file, "r", encoding='utf-8') as file:
            input_text = file.read()

        lines = input_text.strip().split("\n")
        group_name = ""
        for line in lines:
            parts = line.split(",")
            if len(parts) == 2 and "#genre#" in line:
                group_name = parts[0]
            elif len(parts) == 2:
                channel_name = parts[0]
                channel_url = parts[1]
                logo_url=get_logo_by_channel_name(channel_name)
                if logo_url is None:  #not found logo
                    output_text += f"#EXTINF:-1 group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"
                else:
                    output_text += f"#EXTINF:-1  tvg-name=\"{channel_name}\" tvg-logo=\"{logo_url}\"  group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"

        with open(f"{m3u_file}", "w", encoding='utf-8') as file:
            file.write(output_text)

        print(f"M3U文件 '{m3u_file}' 生成成功。")
        #print(f"M3U文件 '{m3u_file_copy}' 生成成功。")
    except Exception as e:
        print(f"发生错误: {e}")


make_m3u(output_full, output_full.replace(".txt", ".m3u"))
make_m3u(output_lite, output_lite.replace(".txt", ".m3u"))
make_m3u(output_custom, output_custom.replace(".txt", ".m3u"))
# 执行结束时间
timeend = datetime.now()

# 计算时间差
elapsed_time = timeend - timestart
total_seconds = elapsed_time.total_seconds()

# 转换为分钟和秒
minutes = int(total_seconds // 60)
seconds = int(total_seconds % 60)
# 格式化开始和结束时间
timestart_str = timestart.strftime("%Y%m%d_%H_%M_%S")
timeend_str = timeend.strftime("%Y%m%d_%H_%M_%S")

print(f"开始时间: {timestart_str}")
print(f"结束时间: {timeend_str}")
print(f"执行时间: {minutes} 分 {seconds} 秒")

combined_blacklist_hj = len(combined_blacklist)
full_lines_count = sum(1 for line in all_lines_full if not line.endswith('#genre#') and line.strip() != '')  # 统计有效行数
print(f"黑名单行数: {combined_blacklist_hj}")
print(f"完整版频道数: {full_lines_count}")
print(f"其他频道行数: {len(other_lines)}")

